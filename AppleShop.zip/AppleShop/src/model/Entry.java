package model;


// Template of a unit of storage in the apple refurbished shop
// Think of a shop as a collection of entries


public class Entry {
	private String serialNumber; // e.g., F9FDN4NKQ1GC (should always be unique)
	private Product product; // the type of attribute is a reference type, denotes an existing class
	
	public Entry(String serialNumber, Product product){
		this.serialNumber = serialNumber;
		this.product = product;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	// An overloaded version of setProduct mutator
	
	public void setProduct(String model, double originalPrice) {
		//this.product = new Product(model, originalPrice);
		Product p = new Product(model, originalPrice);
		this.product = p;
	}
	
	public String toString( ) {
		return "[" + serialNumber + "]" + " " + this.product.toString();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}

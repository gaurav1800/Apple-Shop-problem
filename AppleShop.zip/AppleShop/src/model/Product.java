package model;

// Template for individual Product in the refurbished store

public class Product {
	/* attributes: should be private so that they are only visible within the current class
	 * If an attribute would be public, it becomes visible to all classes */
	
	private String model; // e.g. Ipad Pro 12.9
	private String finish; // e.g. Silver, Space Grey
	private int storage; // e.g. 256GB, 512 gb, 1000 gb
	private boolean hasCellularConnectivity; // if false, only wifi. otherwise wifi + cellular
	private double originalPrice; // e.g. 1789.00
	private double discountValue; // e.g. 200.00
	
	
	// constructors - if none are declared, an implicit constructor is available
	// If implicit constructor is helpful, then define one explicitly. If you do this and add more constructors, 
	// the implicit one becomes unavailable
	public Product() {
		// do nothing: all attributes will be stored in their default values after an object is created
	}
	
	public Product(String model, double originalPrice) {
		this.model = model;
		this.originalPrice = originalPrice;
	}
	
	
	
	// accessors
	public String getModel() {
		return this.model; 
	}
	
	
	
	// mutators
	public void setModel(String model)
	{
		this.model = model;
	}

	public String getFinish() {
		return finish;
	}

	public void setFinish(String finish) {
		this.finish = finish;
	}

	public int getStorage() {
		return storage;
	}

	public void setStorage(int storage) {
		this.storage = storage;
	}

	public boolean hasCellularConnectivity() {
		return hasCellularConnectivity;
	}

	public void setHasCellularConnectivity(boolean hasCellularConnectivity) {
		this.hasCellularConnectivity = hasCellularConnectivity;
	}

	public double getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(double originalPrice) {
		this.originalPrice = originalPrice;
	}

	public double getDiscountValue() {
		return discountValue;
	}

	public void setDiscountValue(double discountValue) {
		this.discountValue = discountValue;
	}
	
	public double getPrice() {
		//Local variable declarations
		double price = 0.0;
		
		//computation
		price = originalPrice - discountValue;
		
		//return
		return price;
	}
	
	public String toString() {
		String s = "";
		
//		StringBuilder sb = new StringBuilder();
//		sb.append(model + " " + finish + " " + storage + "GB " + 
//				"(cellular connectivity: " + hasCellularConnectivity + "): $(" +
//				String.format("%.2f", originalPrice) + " - " + 
//				String.format("%.2f", discountValue) + ")");
//		s = sb.toString();
		
		s+= model + " " + finish + " " + storage + "GB " + 
				"(cellular connectivity: " + hasCellularConnectivity + "): $(" +
				String.format("%.2f", originalPrice) + " - " + 
				String.format("%.2f", discountValue) + ")";
		
//		s = String.format("%s %s %dGB (cellular connectivity: %s): $(%.2f - %.2f)" , 
//				this.model, this.finish, this.storage, this.hasCellularConnectivity,
//				this.originalPrice, this.discountValue);
		
		return s;
	}
	
	
	
}
